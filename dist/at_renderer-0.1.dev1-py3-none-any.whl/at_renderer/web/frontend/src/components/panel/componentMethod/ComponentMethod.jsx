export default ({ label, props }) => {
    return <div {...props}>{label}</div>;
};
